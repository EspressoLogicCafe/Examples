var connectionParams = {
    as400Address: 'address',
    as400User: 'username',
    as400Password:'password',
    as400Library:'LibraryName.LIB'
};
return connectionParams;
