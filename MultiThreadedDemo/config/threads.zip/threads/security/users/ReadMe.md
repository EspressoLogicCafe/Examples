# USERS
This contains Users defined for the system when using the default authentication provider.
While this can be used for production systems, typically the authentication provider is LDAP
or some other mechanism.
