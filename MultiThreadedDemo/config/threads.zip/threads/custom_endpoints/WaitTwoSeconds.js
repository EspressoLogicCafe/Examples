// A trivial endpoint that waits two seconds and returns a JSON string
var Thread  = java.lang.Thread;
print("WaitTwoSeconds endpoint: Sleeping for 2 secs, thread is: " + Thread.currentThread().id);
Thread.sleep(2000);
print("WaitTwoSeconds endpoint: Sleeping is done for thread: " + Thread.currentThread().id);
return JSON.stringify({result: 'Result from WaitTwoSeconds'});
