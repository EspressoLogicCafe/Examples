// A trivial endpoint that waits one second and returns a JSON string
var Thread  = java.lang.Thread;
print("WaitOneSecond endpoint: Sleeping for 1 sec, thread is: " + Thread.currentThread().id);
Thread.sleep(1000);
print("WaitOneSecond endpoint: Sleeping is done for thread: " + Thread.currentThread().id);
return JSON.stringify({result: 'Result from WaitOneSecond'});
