// A trivial endpoint that waits three seconds and returns a JSON string
var Thread  = java.lang.Thread;
print("WaitThreeSeconds endpoint: Sleeping for 3 secs, thread is: " + Thread.currentThread().id);
Thread.sleep(3000);
print("WaitThreeSeconds endpoint: Sleeping is done for thread: " + Thread.currentThread().id);
return JSON.stringify({result: 'Result from WaitThreeSeconds'});
