// This is a simple example of how to make calls to multiple APIs in parallel, so that
// the total execution time will only be slightly longer than the longest call.

print("Begin parallel test");
var startTime = Date.now();

var i;
var response = {};
var executor = java.util.concurrent.Executors.newCachedThreadPool();
var futuresMap = new java.util.concurrent.ConcurrentHashMap();

// For every call, add one of these. The code must return a JSON string.
futuresMap.put("Wait for 1 sec", executor["submit(java.util.concurrent.Callable)"](function(){
    return SysUtility.restGet("http://localhost:8080/http/default/threads/WaitOneSecond", null, null);
}));
futuresMap.put("Wait for 2 secs", executor["submit(java.util.concurrent.Callable)"](function(){
    return SysUtility.restGet("http://localhost:8080/http/default/threads/WaitTwoSeconds", null, null);
}));
futuresMap.put("Wait for 3 secs", executor["submit(java.util.concurrent.Callable)"](function(){
    return SysUtility.restGet("http://localhost:8080/http/default/threads/WaitThreeSeconds", null, null);
}));

// Consolidate the results from each thread.
for (var i = 0; i < 100; i++) {
	var keySet = futuresMap.keySet();
	for each (var key in keySet) {
		var future = futuresMap.get(key);
		if (future.isDone()) {
            var result = future.get();
			response[key] = JSON.parse(result); 
			futuresMap.remove(key);
		}
	}
	if (futuresMap.isEmpty()) {
		break;
	}
	// Avoid a busy loop -- yield CPU time
	java.lang.Thread.sleep(100);
	if (i >= 99) throw "The requests did not complete as expected.";
}
print("All requests have executed in: " + (Date.now() - startTime));
executor.shutdownNow();
return response;
