print("Begin sequential test");
var startTime = Date.now();

var response = {
    Rs1: JSON.parse(SysUtility.restGet("http://localhost:8080/http/default/threads/WaitOneSecond", null, null)),
    Rs2: JSON.parse(SysUtility.restGet("http://localhost:8080/http/default/threads/WaitTwoSeconds", null, null)),
    Rs3: JSON.parse(SysUtility.restGet("http://localhost:8080/http/default/threads/WaitThreeSeconds", null, null))
};
print("All requests have executed in: " + (Date.now() - startTime));
return response;
