# FILTERS
This folder contains definitions for filters
