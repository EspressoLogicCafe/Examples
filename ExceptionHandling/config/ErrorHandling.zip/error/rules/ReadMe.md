This folder contains definitions for rules
