// Insert error event handling code here
var reqResourceName = req.resourceName;
if ("GET" == req.verb){
     if("Error0" == reqResourceName) {
        var temp = json;//JSON response object
        print("ERROR EVENT" + JSON.stringify(json));
        log.debug("ERROR EVENT" + JSON.stringify(json));
        //Modifying the response error to add sucess and payload to the response JSON.
        json = {
            success : false,
            payload:{"Admin Contact":"admin@abctech.com"},
            error: {
                code: temp.errorCode,
                statusCode: temp.statusCode,
                errorMessage: temp.errorMessage,
                message: temp.message
            }
        };
     }else if("Error3" == reqResourceName){
        var temp = json;//JSON response object
        print("ERROR EVENT" + JSON.stringify(json));
        log.debug("ERROR EVENT" + JSON.stringify(json));
        print("req.urlParameters.reqID::" + req.urlParameters.reqID);
        var adminEmail = "admin@abctech.com";
        if(req.urlParameters.reqID%2 === 0){
            adminEmail = "admin@2centTech.com"
        }else{
            adminEmail = "admin@dollarTech.com"
        }
        //Modifying the response error to add sucess and payload to the response JSON.
        json = {
            success : false,
            payload:{"Admin Contact":adminEmail},
            error: {
                code: temp.errorCode,
                statusCode: temp.statusCode,
                errorMessage: temp.errorMessage,
                message: temp.message
            }
        };
     }
}
