This folder contains definitions for request events
