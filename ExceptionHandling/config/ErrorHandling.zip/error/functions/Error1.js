try{
    return {"response": temp}
}catch(e){
    //Send alternate response
    throw "Something went wrong!";
}
