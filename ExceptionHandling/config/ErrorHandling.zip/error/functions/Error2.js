var settings = { headers: { Authorization: "CALiveAPICreator Error_Handle:1" }}
try{
    return {"response": temp}
}catch(e){
    //in case of error call another API
    return JSON.parse(SysUtility.restGet("http://localhost:8080/rest/default/error/v1/ContactAdmin", null, settings));
}
