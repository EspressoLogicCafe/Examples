This folder contains definitions for functions
