//Handled by Response Event.
return {"response": temp}
