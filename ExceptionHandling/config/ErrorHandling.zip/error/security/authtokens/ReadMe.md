This contains statically defined API Keys (Auth Tokens) for this project.
Dynamically created keys (using @authentication service) are NOT exported.
