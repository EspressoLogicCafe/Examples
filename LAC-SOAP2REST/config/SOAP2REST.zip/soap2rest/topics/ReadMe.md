This folder contains definitions for topics
