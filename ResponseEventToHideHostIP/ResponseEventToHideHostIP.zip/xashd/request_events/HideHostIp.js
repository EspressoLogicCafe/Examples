var newJsonResponseObject = []
for (var i = 0; i < json.length; i++){
    var obj = json[i];
    for (var key in obj){
        if(key == '@metadata'){
            var attrValue = obj[key];
            for (var x in attrValue) {
                var str = attrValue[x]
                if(isValidUrl(str)){
                    //example to hide href and next batch ip or hostname
                    var n = str.indexOf("/rest/");
                    var text = str.substring(n,str.length)
                    attrValue[x] = text
                }
                //example to remove the entire links section from response object
                if(x == 'links'){
                    delete obj[key]['links']
                }
            }
        }
    }
    newJsonResponseObject.push(obj)
}
json = newJsonResponseObject


function isValidUrl(string) {
    if(typeof string == 'string'){
        return string.startsWith('http://') || string.startsWith('https://')
        
    }
    return false
}
