# API
This folder contains the content of your API definition.
Name: ResponseEventToHideHostIP
URL Fragment: xashd
Comments: An empty API ready for adding JavaScript functions, JavaScript resources, custom endpoints and data source connections.  

For example, try creating a new function.
